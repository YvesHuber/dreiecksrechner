import { useEffect, useState } from "react";

import * as THREE from "three";

function Test() {
  

  return (
    <div className="App">
      <header className="App-header"></header>
    </div>
  );
}
export default Test;
